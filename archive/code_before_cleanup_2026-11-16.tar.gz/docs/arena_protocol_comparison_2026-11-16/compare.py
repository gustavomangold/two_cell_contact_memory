"""Compare existing legacy and C arena outputs; no simulations or data changes."""
from pathlib import Path
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path('/home/gustavo/Documents/doutorado/repositorios/two_cell_contact_memory')
OUT=Path(__file__).resolve().parent

def read(path):
    with path.open() as file:return list(csv.DictReader(file))

old=read(ROOT/'figures/size_scaling/constant-density/demixing_means.csv')
new=read(ROOT/'figures/paper_arena/constant-density/paper_means.csv')
aligned=[]
for model,rows,factor,speed in [('Legacy arena',old,1/1000,1.),('C arena',new,1.,1000.)]:
    for row in rows:
        if row['metric']!='demixing_index':continue
        tau=float(row['tau'])
        aligned.append(dict(model=model,N=int(row['N']),tau_original=tau,tau_paper=tau*factor,
                            persistent_travel=speed*tau,packing_fraction=float(row['packing_fraction']),
                            mean=float(row['mean']),sem=float(row['sem']),runs=int(row['runs'])))
with (OUT/'aligned_means.csv').open('w',newline='') as file:
    writer=csv.DictWriter(file,fieldnames=list(aligned[0]));writer.writeheader();writer.writerows(aligned)

wall=[]
for number in [16,32,64,128,256,512,1024,2048]:
    for tau in [0.,.001,.01]:
        folder=ROOT/'data/paper_arena/constant-density'/f'N{number}_phi0.4_D360000_tau{tau:.12g}'
        values=[]
        for path in sorted(folder.glob('sample_*.npz')):
            with np.load(path) as data:
                length=float(data['L']);half=number//2
                radius=np.linalg.norm(data['final_positions']-length/2,axis=1)
                values.append([(radius[:half]>(length-1)/2).mean(),(radius[half:]>(length-1)/2).mean(),
                               (radius[:half]>length/2-1.5).mean(),(radius[half:]>length/2-1.5).mean(),
                               (radius[:half]/(length/2)).mean(),(radius[half:]/(length/2)).mean()])
        if not values:continue
        mean=np.mean(values,axis=0);sem=np.std(values,axis=0,ddof=1)/np.sqrt(len(values))
        row=dict(N=number,tau=tau,runs=len(values),L=length)
        for i,name in enumerate(['wall_force_green','wall_force_red','outer_band_green','outer_band_red','mean_radius_green','mean_radius_red']):
            row[name]=mean[i];row[name+'_sem']=sem[i]
        row['uniform_center_reference']=1-((length/2-1.5)/(length/2-.5))**2
        wall.append(row)
with (OUT/'wall_profiles.csv').open('w',newline='') as file:
    writer=csv.DictWriter(file,fieldnames=list(wall[0]));writer.writeheader();writer.writerows(wall)

fig,axes=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
colors=['#315a8a','#19a789','#ab6a25']
for number,color in zip([32,128,512],colors):
    for model,linestyle in [('Legacy arena','--'),('C arena','-')]:
        group=sorted([r for r in aligned if r['N']==number and r['model']==model],key=lambda r:r['persistent_travel'])
        x=np.array([r['persistent_travel'] for r in group]);y=np.array([r['mean'] for r in group]);e=np.array([r['sem'] for r in group])
        axes[0].plot(x,y,linestyle,marker='o',ms=3,color=color,lw=1.5)
        axes[0].fill_between(x,y-e,y+e,color=color,alpha=.08)
axes[0].set_xscale('symlog',linthresh=.0005,linscale=.8)
axes[0].set(xlim=(0,10),ylim=(0,1),xlabel='Nominal persistent travel distance, vτ / σ',ylabel='Final demixing index, ⟨M⟩')
axes[0].set_xticks([0,.001,.01,.1,1,10],labels=['0','0.001','0.01','0.1','1','10'])
first=axes[0].legend(handles=[Line2D([],[],color=c,label=f'N={n}') for n,c in zip([32,128,512],colors)],loc='upper left',frameon=False)
axes[0].add_artist(first)
axes[0].legend(handles=[Line2D([],[],color='#334155',ls='--',label='Legacy arena'),Line2D([],[],color='#334155',label='C arena')],loc='lower right',frameon=False)
group=[r for r in wall if r['tau']==.01]
numbers=np.array([r['N'] for r in group])
for name,color,label in [('outer_band_green','#198754','Green'),('outer_band_red','#d9534f','Red')]:
    axes[1].errorbar(numbers,[r[name] for r in group],yerr=[r[name+'_sem'] for r in group],fmt='o-',ms=4,capsize=2,color=color,label=label)
axes[1].plot(numbers,[r['uniform_center_reference'] for r in group],'--',color='#64748b',label='Uniform center reference')
axes[1].set(xscale='log',ylim=(0,1),xlabel='Particle number, N',ylabel='Fraction of particles near the wall')
axes[1].set_xticks(numbers,labels=[str(n) for n in numbers])
axes[1].legend(title='C arena, τ=0.01',frameon=False)
for ax in axes:
    ax.spines[['top','right']].set_visible(False)
    ax.grid(alpha=.15)
for suffix in ['png','pdf']:fig.savefig(OUT/f'unit_aligned_comparison.{suffix}',dpi=200)
plt.close(fig)

print('Saved unit-aligned comparison; bands/error bars are SEM.')
print('Old CSV snapshot times:',sorted({float(r['final_time']) for r in read(ROOT/'figures/size_scaling/constant-density/demixing_samples.csv')}))
print('Current settings:',json.loads((ROOT/'data/paper_arena/constant-density/settings.json').read_text()))
for n in [128,512,2048]:
    for r in wall:
        if r['N']==n and r['tau']==.01:
            print('N',n,'tau .01 outer band green/red:',r['outer_band_green'],r['outer_band_red'])
