"""Compare saved tau=0 and tau=dt runs without changing any data."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from paper_engine import ROOT

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data-dir',type=Path,default=ROOT/'data/exactly-like-paper')
parser.add_argument('--output',type=Path,default=Path(__file__).with_name('tau_zero_comparison.csv'))
args=parser.parse_args()
fields=['final_positions','final_angles','final_colors','final_rng_state','final_metrics']
rows=[]
for folder in sorted(args.data_dir.glob('N*_phi*_D*_tau0')):
    meta=json.loads((folder/'settings.json').read_text())
    dt=meta['settings']['dt'];phi=meta['settings']['packing_fraction']
    partner=args.data_dir/f"N{meta['N']}_phi{phi:.12g}_D{meta['D']:.12g}_tau{dt:.12g}"
    for path in sorted(folder.glob('sample_*.npz')):
        if not (partner/path.name).exists():continue
        with np.load(path) as a,np.load(partner/path.name) as b:
            equal=[np.array_equal(a[key],b[key],equal_nan=True) for key in fields]
            rows.append([int(a['N']),int(a['sample']),int(a['seed']),*equal])
with args.output.open('w',newline='') as file:
    writer=csv.writer(file);writer.writerow(['N','sample','seed',*fields]);writer.writerows(rows)
print('Compared',len(rows),'pairs of existing runs; all checked fields identical:',all(all(row[3:]) for row in rows))
if not rows:raise SystemExit('No matching saved run pairs were found')
