"""Read-only controlled probes of the inherited code; all builds use /tmp.

Run with PYTHONPATH pointing to the repository's src directory. Requires NumPy,
a C compiler and GSL. Does not modify simulation code or existing run data.
"""
from pathlib import Path
import os
import subprocess
import tempfile

import numpy as np
from paper_engine import DEFAULTS, parameters, prepare_source, domain_size, neighbor_method
from paper_arena import prepare_arena_source


BODY = r'''
static void reset_states(void) {
    InitialiseInternalStates();
    for (int i=0;i<nParticles;i++) particles[i].theta=0;
    simulationTime=0.;
}
int main(int argc, char **argv) {
    SetParameters(argc,argv);
    region.x=region.y=8.; cells.x=cells.y=4;
    AllocArrays(); reset_states();
    particles[2].r=(VecR){1.5,4}; particles[3].r=(VecR){6.5,4};
    for(int translated=0;translated<2;translated++) {
        particles[0].r=(VecR){3.7+.2*translated,4.1};
        particles[1].r=(VecR){3.9+.2*translated,4.1};
        BuildNeighbourList(); ComputeInteractions();
        printf("AUDIT pair translated=%d count=%d fx0=%.17g\n",translated,nNeighbourPairs,particles[0].force.x);
    }
    for(int reversed=0;reversed<2;reversed++) {
        reset_states();
        particles[0].r=(VecR){3.4,4.1}; particles[1].r=(VecR){4.6,4.1};
        particles[2].r=(VecR){4.,4.1}; particles[3].r=(VecR){1.5,4};
        nNeighbourPairs=2;
        neighbourList[0]=reversed; neighbourList[1]=2;
        neighbourList[2]=1-reversed; neighbourList[3]=2;
        tau=.001;
        for(int step=0;step<200;step++) {
            simulationTime=step*stepDuration;
            ComputeInteractions(); UpdateInternalStates();
            if(step==0 || step==199)
                printf("AUDIT shared_red reversed=%d step=%d green_colors=%d,%d\n",
                       reversed,step+1,particles[0].color,particles[1].color);
        }
    }
    reset_states(); tau=0.; nNeighbourPairs=1;
    neighbourList[0]=0; neighbourList[1]=2;
    ComputeInteractions(); UpdateInternalStates();
    printf("AUDIT tau_zero after_contact color=%d noise_amplitude=%.17g timer=%.17g\n",
           particles[0].color,particles[0].D,particles[0].decayTimer);
    int active=0;
    for(int step=0;step<20;step++) {
        ComputeInteractions(); UpdateInternalStates();
        active += particles[0].color==2 && particles[0].D==0.;
    }
    printf("AUDIT tau_zero continuous_contact_active_updates=%d/20\n",active);
    nNeighbourPairs=0; ComputeInteractions(); UpdateInternalStates();
    printf("AUDIT tau_zero after_next_update_without_contact color=%d noise_amplitude=%.17g\n",
           particles[0].color,particles[0].D);
    reset_states();
    particles[0].r=particles[2].r=(VecR){4.,4.1};
    nNeighbourPairs=1; neighbourList[0]=0; neighbourList[1]=2;
    ComputeInteractions();
    printf("AUDIT exact_overlap force_finite=%d\n",isfinite(particles[0].force.x));
    return 0;
}
'''

for arena in [False, True]:
    print('\nBUILD', 'circular-arena' if arena else 'periodic-square', flush=True)
    with tempfile.TemporaryDirectory(prefix='mechanism_probe_') as directory:
        root = Path(directory)
        source = root / 'source'
        (prepare_arena_source if arena else prepare_source)(source)
        driver = source / 'driver.c'
        prelude = driver.read_text().split('int main(int argc, char **argv) {')[0]
        driver.write_text(prelude + BODY)
        command = ['cc','-O2','-std=gnu11','source/driver.c','source/upstream/cell_simulation.c','source/upstream/xoshiro_rng.c']
        if arena:
            command.append('source/arena.c')
        command += ['-lgsl','-lgslcblas','-lm','-o','probe']
        subprocess.run(command,cwd=root,check=True,capture_output=True,text=True)
        params = parameters(4,360000.,.001,{**DEFAULTS,'duration':.002})
        (root/'parameters').write_text(''.join(f'{k} : {v:.17g}\n' for k,v in params.items()))
        result = subprocess.run([str(root/'probe'),'parameters'],cwd=root,check=True,capture_output=True,text=True,
                                env={**os.environ,'PAPER_SEED':'7','PAPER_WALL_STIFFNESS':'30000'})
        for line in result.stdout.splitlines():
            if line.startswith('AUDIT '):
                print(line)

print('\nGEOMETRY phi=0.4 (center-area ratio is a geometric reference, not an exact soft-wall density)')
for n in [2,4,8,16,32,128,512]:
    length=domain_size(n,.4,'circular-arena')
    print(n,'diameter',length,'outer_area/center_area',(length/(length-1))**2,
          'periodic_method',neighbor_method(n,.4),'arena_method',neighbor_method(n,.4,'circular-arena'),
          'random_label_M',(n/2-1)/(n-1))
dr=360000.;speed=1000.;dt=1e-5
continuous=1+speed**2/(2*dr)
discrete=1+speed**2*dt/4/np.tanh(dr*dt/2)
print('\nFREE_ABP analytic D_eff continuous=',continuous,'Euler=',discrete,'ratio=',discrete/continuous)
